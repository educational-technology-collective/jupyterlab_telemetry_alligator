"""Python unit tests for jupyterlab_telemetry_alligator."""
