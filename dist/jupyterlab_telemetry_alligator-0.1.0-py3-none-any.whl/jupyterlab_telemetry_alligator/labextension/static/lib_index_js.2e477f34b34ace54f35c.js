"use strict";
(self["webpackChunk_educational_technology_collective_jupyterlab_telemetry_alligator"] = self["webpackChunk_educational_technology_collective_jupyterlab_telemetry_alligator"] || []).push([["lib_index_js"],{

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "requestAPI": () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'jupyterlab-telemetry-alligator', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MessageAdapater": () => (/* binding */ MessageAdapater),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _educational_technology_collective_etc_jupyterlab_notebook_state_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @educational-technology-collective/etc_jupyterlab_notebook_state_provider */ "webpack/sharing/consume/default/@educational-technology-collective/etc_jupyterlab_notebook_state_provider");
/* harmony import */ var _educational_technology_collective_etc_jupyterlab_notebook_state_provider__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_educational_technology_collective_etc_jupyterlab_notebook_state_provider__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _educational_technology_collective_etc_jupyterlab_telemetry_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @educational-technology-collective/etc_jupyterlab_telemetry_library */ "webpack/sharing/consume/default/@educational-technology-collective/etc_jupyterlab_telemetry_library");
/* harmony import */ var _educational_technology_collective_etc_jupyterlab_telemetry_library__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_educational_technology_collective_etc_jupyterlab_telemetry_library__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");



// import { ISettingRegistry } from '@jupyterlab/settingregistry';

const PLUGIN_ID = '@educational-technology-collective/jupyterlab_telemetry_alligator:plugin';
class MessageAdapater {
    constructor({ etcJupyterLabNotebookStateProvider }) {
        var _a, _b, _c;
        this._etcJupyterLabNotebookStateProvider = etcJupyterLabNotebookStateProvider;
        let hubUser = (_c = (_b = (_a = document === null || document === void 0 ? void 0 : document.cookie) === null || _a === void 0 ? void 0 : _a.split('; ')) === null || _b === void 0 ? void 0 : _b.find(row => row.startsWith('hub_user='))) === null || _c === void 0 ? void 0 : _c.split('=')[1];
        this._userId = hubUser ? hubUser : "UNDEFINED";
    }
    async adaptMessage(sender, data) {
        try {
            let notebookState = this._etcJupyterLabNotebookStateProvider.getNotebookState({
                notebookPanel: data.notebookPanel
            });
            let notebookPath = data.notebookPanel.context.path;
            let message = Object.assign(Object.assign({ 'event_name': data.eventName, 'cells': data.cells }, notebookState), {
                user_id: this._userId,
                notebook_path: notebookPath
            });
            if (data.meta) {
                message['meta'] = data.meta;
            }
            console.log('Request', message);
            let response = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('telemetry', { method: 'POST', body: JSON.stringify(message) });
            message = Object.assign({}, message);
            delete message.notebook;
            delete message.cells;
            console.log('Response', {
                'response': response,
                'message': message
            });
        }
        catch (e) {
            console.error(e);
        }
    }
}
/**
 * Initialization data for the @educational-technology-collective/jupyterlab_telemetry_alligator extension.
 */
const plugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker,
        _educational_technology_collective_etc_jupyterlab_notebook_state_provider__WEBPACK_IMPORTED_MODULE_1__.IETCJupyterLabNotebookStateProvider,
        _educational_technology_collective_etc_jupyterlab_telemetry_library__WEBPACK_IMPORTED_MODULE_2__.IETCJupyterLabTelemetryLibraryFactory
    ],
    activate: (app, notebookTracker, etcJupyterLabNotebookStateProvider, etcJupyterLabTelemetryLibraryFactory) => {
        let messageAdapter;
        let telemetry = (async () => {
            try {
                await app.started;
                const VERSION = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('version');
                console.log(`${PLUGIN_ID}, ${VERSION}`);
                let result = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('telemetry');
                console.log('telemetry', result);
                if (!result.telemetry) {
                    notebookTracker.widgetAdded.disconnect(onWidgetAdded, undefined);
                }
                return result.telemetry;
            }
            catch (e) {
                console.error(e);
                notebookTracker.widgetAdded.disconnect(onWidgetAdded, undefined);
                return false;
            }
        })();
        async function onWidgetAdded(sender, notebookPanel) {
            //  Handlers must be attached immediately in order to detect early events, hence we do not want to await the appearance of the Notebook.
            if (await telemetry) {
                if (!messageAdapter) {
                    messageAdapter = new MessageAdapater({ etcJupyterLabNotebookStateProvider });
                }
                etcJupyterLabNotebookStateProvider.addNotebookPanel({ notebookPanel });
                let etcJupyterLabTelemetryLibrary = etcJupyterLabTelemetryLibraryFactory.create({ notebookPanel });
                etcJupyterLabTelemetryLibrary.notebookClipboardEvent.notebookClipboardCopied.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.notebookClipboardEvent.notebookClipboardCut.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.notebookClipboardEvent.notebookClipboardPasted.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.notebookVisibilityEvent.notebookVisible.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.notebookVisibilityEvent.notebookHidden.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.notebookOpenEvent.notebookOpened.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.notebookCloseEvent.notebookClosed.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.notebookSaveEvent.notebookSaved.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.notebookScrollEvent.notebookScrolled.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.activeCellChangeEvent.activeCellChanged.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.cellAddEvent.cellAdded.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.cellRemoveEvent.cellRemoved.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.cellExecutionEvent.cellExecuted.connect(messageAdapter.adaptMessage, messageAdapter);
                etcJupyterLabTelemetryLibrary.cellErrorEvent.cellErrored.connect(messageAdapter.adaptMessage, messageAdapter);
            }
        }
        notebookTracker.widgetAdded.connect(onWidgetAdded, undefined);
        // if (settingRegistry) {
        //   settingRegistry
        //     .load(plugin.id)
        //     .then(settings => {
        //       console.log('@educational-technology-collective/jupyterlab_telemetry_alligator settings loaded:', settings.composite);
        //     })
        //     .catch(reason => {
        //       console.error('Failed to load settings for @educational-technology-collective/jupyterlab_telemetry_alligator.', reason);
        //     });
        // }
        // requestAPI<any>('get_example')
        //   .then(data => {
        //     console.log(data);
        //   })
        //   .catch(reason => {
        //     console.error(
        //       `The jupyterlab_telemetry_alligator server extension appears to be missing.\n${reason}`
        //     );
        //   });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.2e477f34b34ace54f35c.js.map